package com.example.ArchiveService.Controller;

import com.example.ArchiveService.Service.ArchiveServiceImpl;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/v4")
public class ArchiveController
{
	private ArchiveServiceImpl service;
	@Autowired
	public ArchiveController(ArchiveServiceImpl service)
	{
		this.service=service;
	}
	@GetMapping("/gettasks")
	public ResponseEntity gettasks(HttpServletRequest request) {
		try {
			Claims claims = (Claims) request.getAttribute ("claims");
			String authheader = request.getHeader ("Authorization");
			System.out.println ("Authheader:" + authheader);
			String emailId = claims.getSubject ();
			return new ResponseEntity<> (service.getArchivedTasks(emailId, authheader), HttpStatus.ACCEPTED);
		} catch (Exception e) {
			throw new RuntimeException (e);
		}
	}
	@GetMapping("/archivedTaskByPriority")
	public ResponseEntity archivedTaskByPriority(HttpServletRequest request) {
		try {
			Claims claims = (Claims) request.getAttribute ("claims");
			String authheader = request.getHeader ("Authorization");
			System.out.println ("Authheader:" + authheader);
			String emailId = claims.getSubject ();
			return new ResponseEntity<> (service.archivedTaskSortedByPriority (emailId, authheader), HttpStatus.ACCEPTED);
		} catch (Exception e) {
			throw new RuntimeException (e);
		}
	}
	@GetMapping("/archivedTaskByCompletion")
	public ResponseEntity archivedTaskByCompletion(HttpServletRequest request) {
		try {
			Claims claims = (Claims) request.getAttribute ("claims");
			String authheader = request.getHeader ("Authorization");
			System.out.println ("Authheader:" + authheader);
			String emailId = claims.getSubject ();
			return new ResponseEntity<> (service.archivedTaskSortedCompletionStatus (emailId, authheader), HttpStatus.ACCEPTED);
		} catch (Exception e) {
			throw new RuntimeException (e);
		}
	}
	@GetMapping("/archivedTaskByDate")
	public ResponseEntity archivedTaskByDate(HttpServletRequest request) {
		try {
			Claims claims = (Claims) request.getAttribute ("claims");
			String authheader = request.getHeader ("Authorization");
			System.out.println ("Authheader:" + authheader);
			String emailId = claims.getSubject ();
			return new ResponseEntity<> (service.archivedTaskSortedByDate (emailId, authheader), HttpStatus.ACCEPTED);
		} catch (Exception e) {
			throw new RuntimeException (e);
		}
	}

}
