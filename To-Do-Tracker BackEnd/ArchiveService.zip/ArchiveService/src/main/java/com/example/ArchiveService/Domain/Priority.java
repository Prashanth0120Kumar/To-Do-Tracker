package com.example.ArchiveService.Domain;

public enum Priority
{
	LOW,
	MEDIUM,
	HIGH
}