package com.example.ArchiveService.Service;

import com.example.ArchiveService.Exception.TaskNotFoundException;
import com.example.TaskService.Domain.Task;

import java.util.List;

public interface ArchiveService
{
	List<Task> getArchivedTasks(String email, String authHeader) throws TaskNotFoundException;
	List<Task> archivedTaskSortedByPriority(String email,String authHeader) throws TaskNotFoundException;
	List<Task> archivedTaskSortedCompletionStatus(String email,String authHeader) throws TaskNotFoundException;
	List<Task> archivedTaskSortedByTime(String email,String authHeader) throws TaskNotFoundException;
	List<Task> archivedTaskSortedByDate(String email,String authHeader) throws TaskNotFoundException;
}
