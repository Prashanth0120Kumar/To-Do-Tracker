package com.example.ArchiveService.Service;

import com.example.ArchiveService.Exception.TaskNotFoundException;
import com.example.ArchiveService.Proxy.ArchiveProxy;
import com.example.ArchiveService.Repository.ArchiveRepository;
import com.example.TaskService.Domain.Priority;
import com.example.TaskService.Domain.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
@Service
public class ArchiveServiceImpl implements ArchiveService
{
	private ArchiveRepository repos;
	private ArchiveProxy proxy;
	@Autowired
	public ArchiveServiceImpl(ArchiveRepository repos,ArchiveProxy proxy)
	{
		this.proxy=proxy;
		this.repos=repos;
	}
	
	@Override
	public List<Task> getArchivedTasks(String email, String authHeader) throws TaskNotFoundException
	{
		ResponseEntity<List<Task>> response = proxy.getArchivedTasks(email, authHeader);
		if (response.getStatusCode() == HttpStatus.OK)
		{
			return response.getBody();
		} else
		{
			throw new TaskNotFoundException ("Failed to retrieve archived tasks");
		}
	}
	@Override
	public List<Task> archivedTaskSortedByPriority(String email, String authHeader) throws TaskNotFoundException {
		List<Task> tasksForToday = getArchivedTasks (email, authHeader);
		Comparator<Task> priorityComparator = Comparator.comparing(task -> {
			Priority priority = task.getPriorityLevel();
			if (priority == Priority.HIGH) {
				return 1;
			} else if (priority == Priority.MEDIUM) {
				return 2;
			} else {
				return 3;
			}
		});
		tasksForToday.sort (priorityComparator);
		return tasksForToday;
	}
	@Override
	public List<Task> archivedTaskSortedCompletionStatus(String email, String authHeader) throws TaskNotFoundException {
		List<Task> tasksForToday = getArchivedTasks (email, authHeader);
		Comparator<Task> completionChecker = Comparator.comparing(task -> {
			boolean completionStatus = task.isCompleted ();
			if (completionStatus == true) {
				return 1;
			} else
			{
				return 2;
			}
		});
		tasksForToday.sort (completionChecker);
		return tasksForToday;
	}
	@Override
	public List<Task> archivedTaskSortedByTime(String email, String authHeader) throws TaskNotFoundException {
		List<Task> tasksForToday = getArchivedTasks (email, authHeader);
		Comparator<Task> timeComparator = (task1, task2) -> task1.getDueTime ().compareTo(task2.getDueTime ());
		
		tasksForToday.sort(timeComparator);
		
		return tasksForToday;
	}
	
	@Override
	public List<Task> archivedTaskSortedByDate(String email, String authHeader) throws TaskNotFoundException {
		List<Task> tomorrowTasks = getArchivedTasks (email, authHeader);
		Comparator<Task> dateAndTimeComparator = (task1, task2) -> {
			LocalDate dueDate1 = task1.getDueDate ();
			LocalDate dueDate2 = task2.getDueDate ();
			if (dueDate1.isEqual (dueDate2)) {
				LocalTime time1 = task1.getDueTime ();
				LocalTime time2 = task2.getDueTime ();
				return time1.compareTo (time2);
			} else {
				return dueDate1.compareTo (dueDate2);
			}
		};
		tomorrowTasks.sort (dateAndTimeComparator);
		return tomorrowTasks;
	}
}


