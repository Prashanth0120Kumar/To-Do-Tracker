package com.example.ArchiveService.Proxy;

import com.example.TaskService.Domain.Task;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "task-service", url = "http://localhost:8087")
public interface ArchiveProxy
{
	@GetMapping("/api/v2/user/archived")
	public ResponseEntity<List<Task>> getArchivedTasks(@RequestParam("userEmail") String userEmail, @RequestHeader("Authorization") String authHeader);
}
