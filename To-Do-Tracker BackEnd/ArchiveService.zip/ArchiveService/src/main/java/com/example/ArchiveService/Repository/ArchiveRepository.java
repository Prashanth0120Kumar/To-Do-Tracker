package com.example.ArchiveService.Repository;

import com.example.ArchiveService.Domain.Task;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ArchiveRepository extends MongoRepository<Task,Integer> {
}
