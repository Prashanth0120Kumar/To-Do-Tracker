package com.example.ArchiveService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchiveServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
