export type LOGIN =
{
    userEmail:string;
    userPassword:string;
}